<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\books;

class BookSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $filename = 'database/seeders/books.csv';
        $file = fopen($filename, "r");
        $data = array();        
     
        $firstline = true;
        while (($data = fgetcsv($file, 200, ",")) !== FALSE) {
        
            if (!$firstline) {
                books::create([
                    "Title" => $data["0"],
                    "Author" => $data["1"],
                    "Description" => $data["2"],
                    "Publication_Year" => $data["3"]
                ]);    
            }
            $firstline = false;
        
   
      
    }
    fclose($file);
    }
}

