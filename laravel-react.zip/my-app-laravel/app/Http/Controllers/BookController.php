<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\books;

class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $books = books::all();
        return $books;
    }

    /**
     * Display the specified resource.
     */
    public function show(Request $Request)
    {

        $parameterName = $Request->get('ParameterName');
        $parameterValue = $Request->get('ParameterValue');
      
        /*** Example Data ****/
        // Example year -> 2015 
        //Example Author -> Hajime Isayama
    
        if($parameterName == "year"){
            $book = books::where('Publication_Year', '=', $parameterValue)->firstOrFail();
            return $book;
        }
        if($parameterName == "author"){
            $book = books::where('Author', '=', $parameterValue)->firstOrFail();
            return $book;
       }

    
    
    }
}
