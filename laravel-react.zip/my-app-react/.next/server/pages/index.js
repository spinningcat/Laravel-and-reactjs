"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./src/pages/index.js":
/*!****************************!*\
  !*** ./src/pages/index.js ***!
  \****************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! axios */ \"axios\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_2__]);\naxios__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\nconst searchComponent = ()=>{\n    const [inputText, setInputText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(\"\");\n    const [post, setPost] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);\n    let params = \"\";\n    async function handle() {\n        const baseURL = \"http://127.0.0.1:8000/api/booksearch\";\n        if (/^[0-9]+$/.test(inputText)) {\n            params = new URLSearchParams([\n                [\n                    \"ParameterName\",\n                    \"year\"\n                ],\n                [\n                    \"ParameterValue\",\n                    inputText\n                ]\n            ]);\n        } else {\n            params = new URLSearchParams([\n                [\n                    \"ParameterName\",\n                    \"author\"\n                ],\n                [\n                    \"ParameterValue\",\n                    inputText\n                ]\n            ]);\n        }\n        const result = await axios__WEBPACK_IMPORTED_MODULE_2__[\"default\"].get(baseURL, {\n            params\n        });\n        // I just update post with setPost.\n        setPost(result.data);\n    }\n    ;\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                inputText: inputText,\n                onChange: (e)=>{\n                    setInputText(e.target.value);\n                }\n            }, void 0, false, {\n                fileName: \"/var/www/html/assigment/Laravel-and-reactjs/my-app-react/src/pages/index.js\",\n                lineNumber: 30,\n                columnNumber: 5\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: handle,\n                children: \"Search\"\n            }, void 0, false, {\n                fileName: \"/var/www/html/assigment/Laravel-and-reactjs/my-app-react/src/pages/index.js\",\n                lineNumber: 34,\n                columnNumber: 5\n            }, undefined),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                        children: [\n                            \" \",\n                            post.Title,\n                            \" \"\n                        ]\n                    }, void 0, true, {\n                        fileName: \"/var/www/html/assigment/Laravel-and-reactjs/my-app-react/src/pages/index.js\",\n                        lineNumber: 38,\n                        columnNumber: 7\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                        children: [\n                            \"  \",\n                            post.Author,\n                            \"  \"\n                        ]\n                    }, void 0, true, {\n                        fileName: \"/var/www/html/assigment/Laravel-and-reactjs/my-app-react/src/pages/index.js\",\n                        lineNumber: 39,\n                        columnNumber: 7\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                        children: [\n                            \"  \",\n                            post.Description,\n                            \" \"\n                        ]\n                    }, void 0, true, {\n                        fileName: \"/var/www/html/assigment/Laravel-and-reactjs/my-app-react/src/pages/index.js\",\n                        lineNumber: 40,\n                        columnNumber: 7\n                    }, undefined),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"p\", {\n                        children: [\n                            \"  \",\n                            post.Publication_Year,\n                            \" \"\n                        ]\n                    }, void 0, true, {\n                        fileName: \"/var/www/html/assigment/Laravel-and-reactjs/my-app-react/src/pages/index.js\",\n                        lineNumber: 41,\n                        columnNumber: 7\n                    }, undefined)\n                ]\n            }, void 0, true, {\n                fileName: \"/var/www/html/assigment/Laravel-and-reactjs/my-app-react/src/pages/index.js\",\n                lineNumber: 37,\n                columnNumber: 5\n            }, undefined)\n        ]\n    }, void 0, true, {\n        fileName: \"/var/www/html/assigment/Laravel-and-reactjs/my-app-react/src/pages/index.js\",\n        lineNumber: 29,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (searchComponent);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvaW5kZXguanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUF5QjtBQUNNO0FBQ0w7QUFHMUIsTUFBTUcsa0JBQW1CLElBQUs7SUFFNUIsTUFBTSxDQUFDQyxXQUFXQyxhQUFhLEdBQUdKLCtDQUFRQSxDQUFDO0lBQzNDLE1BQU0sQ0FBQ0ssTUFBTUMsUUFBUSxHQUFHTiwrQ0FBUUEsQ0FBQyxFQUFFO0lBQ25DLElBQUlPLFNBQVM7SUFDYixlQUFlQyxTQUFTO1FBRXRCLE1BQU1DLFVBQVU7UUFHaEIsSUFBRyxXQUFXQyxJQUFJLENBQUNQLFlBQVc7WUFDNUJJLFNBQVMsSUFBSUksZ0JBQWdCO2dCQUFDO29CQUFDO29CQUFpQjtpQkFBTztnQkFBRTtvQkFBRTtvQkFBa0JSO2lCQUFZO2FBQUM7UUFDNUYsT0FDSTtZQUNGSSxTQUFTLElBQUlJLGdCQUFnQjtnQkFBQztvQkFBQztvQkFBaUI7aUJBQVM7Z0JBQUU7b0JBQUU7b0JBQWtCUjtpQkFBWTthQUFDO1FBQzlGLENBQUM7UUFDRCxNQUFNUyxTQUFTLE1BQU1YLGlEQUFTLENBQzVCUSxTQUFTO1lBQUVGO1FBQU87UUFDbEIsbUNBQW1DO1FBQ25DRCxRQUFRTSxPQUFPRSxJQUFJO0lBRXJCOztJQUNBLHFCQUNBLDhEQUFDQzs7MEJBQ0QsOERBQUNDO2dCQUNDYixXQUFXQTtnQkFDWGMsVUFBVSxDQUFDQyxJQUFNO29CQUFDZCxhQUFhYyxFQUFFQyxNQUFNLENBQUNDLEtBQUs7Z0JBQUM7Ozs7OzswQkFFaEQsOERBQUNDO2dCQUFPQyxTQUFXZDswQkFBUTs7Ozs7OzBCQUczQiw4REFBQ087O2tDQUNDLDhEQUFDUTs7NEJBQUU7NEJBQUVsQixLQUFLbUIsS0FBSzs0QkFBQzs7Ozs7OztrQ0FDaEIsOERBQUNEOzs0QkFBRTs0QkFBR2xCLEtBQUtvQixNQUFNOzRCQUFDOzs7Ozs7O2tDQUNsQiw4REFBQ0Y7OzRCQUFFOzRCQUFHbEIsS0FBS3FCLFdBQVc7NEJBQUM7Ozs7Ozs7a0NBQ3ZCLDhEQUFDSDs7NEJBQUU7NEJBQUdsQixLQUFLc0IsZ0JBQWdCOzRCQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBR2pDO0FBRUQsaUVBQWV6QixlQUFlQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbXktYXBwLXJlYWN0Ly4vc3JjL3BhZ2VzL2luZGV4LmpzPzQwODAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHJlYWN0IGZyb20gXCJyZWFjdFwiXG5pbXBvcnQge3VzZVN0YXRlfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XG5cblxuY29uc3Qgc2VhcmNoQ29tcG9uZW50ID0gKCgpID0+e1xuXG4gIGNvbnN0IFtpbnB1dFRleHQsIHNldElucHV0VGV4dF0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtwb3N0LCBzZXRQb3N0XSA9IHVzZVN0YXRlKFtdKTtcbiAgbGV0IHBhcmFtcyA9IFwiXCI7XG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZSgpIHtcbiAgIFxuICAgIGNvbnN0IGJhc2VVUkwgPSBcImh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hcGkvYm9va3NlYXJjaFwiXG5cbiAgICBcbiAgICBpZigvXlswLTldKyQvLnRlc3QoaW5wdXRUZXh0KSl7XG4gICAgICBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKFtbXCJQYXJhbWV0ZXJOYW1lXCIsIFwieWVhclwiXSwgWyBcIlBhcmFtZXRlclZhbHVlXCIsIGlucHV0VGV4dCAgXV0pO1xuICAgIH1cbiAgICBlbHNle1xuICAgICAgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhbW1wiUGFyYW1ldGVyTmFtZVwiLCBcImF1dGhvclwiXSwgWyBcIlBhcmFtZXRlclZhbHVlXCIsIGlucHV0VGV4dCAgXV0pO1xuICAgIH1cbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBheGlvcy5nZXQoXG4gICAgICBiYXNlVVJMLCB7IHBhcmFtcyB9KVxuICAgICAgLy8gSSBqdXN0IHVwZGF0ZSBwb3N0IHdpdGggc2V0UG9zdC5cbiAgICAgIHNldFBvc3QocmVzdWx0LmRhdGEpO1xuICAgICAgXG4gICAgfTtcbiAgICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgPGlucHV0IFxuICAgICAgaW5wdXRUZXh0PXtpbnB1dFRleHR9IFxuICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7c2V0SW5wdXRUZXh0KGUudGFyZ2V0LnZhbHVlKX19IFxuICAgIC8+XG4gICAgPGJ1dHRvbiBvbkNsaWNrID0ge2hhbmRsZX0+XG4gICAgICBTZWFyY2hcbiAgICA8L2J1dHRvbj5cbiAgICA8ZGl2PlxuICAgICAgPHA+IHtwb3N0LlRpdGxlfSA8L3A+XG4gICAgICA8cD4gIHtwb3N0LkF1dGhvcn0gIDwvcD5cbiAgICAgIDxwPiAge3Bvc3QuRGVzY3JpcHRpb259IDwvcD5cbiAgICAgIDxwPiAge3Bvc3QuUHVibGljYXRpb25fWWVhcn0gPC9wPlxuICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuKX0pO1xuICAgICAgXG5leHBvcnQgZGVmYXVsdCBzZWFyY2hDb21wb25lbnQ7Il0sIm5hbWVzIjpbInJlYWN0IiwidXNlU3RhdGUiLCJheGlvcyIsInNlYXJjaENvbXBvbmVudCIsImlucHV0VGV4dCIsInNldElucHV0VGV4dCIsInBvc3QiLCJzZXRQb3N0IiwicGFyYW1zIiwiaGFuZGxlIiwiYmFzZVVSTCIsInRlc3QiLCJVUkxTZWFyY2hQYXJhbXMiLCJyZXN1bHQiLCJnZXQiLCJkYXRhIiwiZGl2IiwiaW5wdXQiLCJvbkNoYW5nZSIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsImJ1dHRvbiIsIm9uQ2xpY2siLCJwIiwiVGl0bGUiLCJBdXRob3IiLCJEZXNjcmlwdGlvbiIsIlB1YmxpY2F0aW9uX1llYXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/index.js\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/index.js"));
module.exports = __webpack_exports__;

})();