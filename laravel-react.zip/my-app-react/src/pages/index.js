import react from "react"
import {useState} from 'react';
import axios from "axios";


const searchComponent = (() =>{

  const [inputText, setInputText] = useState('');
  const [post, setPost] = useState([]);
  let params = "";
  async function handle() {
   
    const baseURL = "http://127.0.0.1:8000/api/booksearch"

    
    if(/^[0-9]+$/.test(inputText)){
      params = new URLSearchParams([["ParameterName", "year"], [ "ParameterValue", inputText  ]]);
    }
    else{
      params = new URLSearchParams([["ParameterName", "author"], [ "ParameterValue", inputText  ]]);
    }
    const result = await axios.get(
      baseURL, { params })
      // I just update post with setPost.
      setPost(result.data);
      
    };
    return (
    <div>
    <input 
      inputText={inputText} 
      onChange={(e) => {setInputText(e.target.value)}} 
    />
    <button onClick = {handle}>
      Search
    </button>
    <div>
      <p> {post.Title} </p>
      <p>  {post.Author}  </p>
      <p>  {post.Description} </p>
      <p>  {post.Publication_Year} </p>
    </div>
    </div>
)});
      
export default searchComponent;